#pragma once

class ievent_callback
{
public:
	virtual void operator() () = 0;
};