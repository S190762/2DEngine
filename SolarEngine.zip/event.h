#pragma once
#include "ievent_callback.h"
#include <vector>

class event
{
private:
	typedef std::vector<ievent_callback*> callback_array;
	callback_array actions_;
public:
	event() {}
	~event() {}
	void add_listener(ievent_callback* action)
	{
		auto pos = find(actions_.begin(), actions_.end(), action);
		if (pos != actions_.end())
		{
			return;
		}
		actions_.push_back(action);
	}
	void remove_listener(ievent_callback* action)
	{
		const auto pos = find(actions_.begin(), actions_.end(), action);
		if (pos == actions_.end())
		{
			return;
		}
		actions_.erase(pos);
	}
	void fire()
	{
		for (ievent_callback* action : actions_)
		{
			(*action)();
		}
	}
};
