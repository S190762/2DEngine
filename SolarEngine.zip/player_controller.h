#pragma once
#include <SFML/Graphics.hpp>
#include "input_manager.h"

class player_controller
{
private:
	sf::Texture player_texture_;
	sf::Sprite player_sprite_;
	sf::RectangleShape debug_shape_;
	sf::Vector2f player_position_;
public:
	player_controller()
	{
		//load player
		player_texture_.loadFromFile("player.png");
		player_sprite_.setTexture(player_texture_);
		//set random position
		player_position_ = { (float)(rand() % 700), (float)(rand() % 500) };
		debug_shape_.setSize({ player_sprite_.getGlobalBounds().width, player_sprite_.getGlobalBounds().height });
		debug_shape_.setOutlineThickness(3.f);
		debug_shape_.setFillColor(sf::Color::Transparent);
		debug_shape_.setOutlineColor(sf::Color::Red);
		//register input callbacks
		input_manager::instance().add<player_controller>("MOVE_LEFT", this, &player_controller::move_left);
		input_manager::instance().add<player_controller>("MOVE_RIGHT", this, &player_controller::move_right);
		input_manager::instance().add<player_controller>("MOVE_UP", this, &player_controller::move_up);
		input_manager::instance().add<player_controller>("MOVE_DOWN", this, &player_controller::move_down);
	}
	sf::Sprite & get_sprite()
	{
		return player_sprite_;
	}
	void move_right()
	{
		player_position_.x += 15;
	}
	void move_left()
	{
		player_position_.x -= 15;
	}
	void move_up()
	{
		player_position_.y -= 15;
	}
	void move_down()
	{
		player_position_.y += 15;
	}
	void render(sf::RenderWindow & window)
	{
		player_sprite_.setPosition(player_position_);
		debug_shape_.setPosition(player_position_);
		window.draw(debug_shape_);
		window.draw(player_sprite_);
	}
};
