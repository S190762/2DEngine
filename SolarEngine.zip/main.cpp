#include <SFML/Graphics.hpp>
#include <memory>
#include "input_manager.h"
#include "player_controller.h"
#include <iostream>
#include <sol.hpp>

struct sprite
{
	sf::Texture texture;
	sf::Sprite spritee;
	sprite(std::string & filename)
	{
		texture.loadFromFile(filename);
		spritee.setTexture(texture);
	}
	bool check_collison(sf::FloatRect & other)
	{
		return spritee.getGlobalBounds().intersects(other);
	}
};

struct debug_shape
{
	sf::RectangleShape shape;
	void init(sprite sp)
	{
		shape.setSize({ sp.spritee.getGlobalBounds().width, sp.spritee.getGlobalBounds().height });
		shape.setOutlineThickness(3.f);
		shape.setFillColor(sf::Color::Transparent);
		shape.setOutlineColor(sf::Color::Red);
	}
};

class entity
{
private:
	sf::Vector2f position_;
	sprite sprite_;
	bool debug = false;
	debug_shape debug_;
	bool block = false;
public:
	virtual ~entity() {}
	entity(std::string filename, bool d) : sprite_(filename), debug(d), position_(0, 0)
	{
		if(debug)
			debug_.init(sprite_);
	}
	void set_pos(int x, int y)
	{
		position_.x += x;
		position_.y += y;
		sprite_.spritee.setPosition(position_);
	}
	void render(sf::RenderWindow & window)
	{
		if (debug) {
			debug_.shape.setPosition(position_);
			window.draw(debug_.shape);
		}
		window.draw(sprite_.spritee);
	}
	sprite & get_sprite()
	{
		return sprite_;
	}
};



class player_controller2 : public entity
{
public:
	player_controller2() : entity("player.png", true)
	{
		//set random position
		set_pos((float)(rand() % 700), (float)(rand() % 500));
		//register input callbacks
		input_manager::instance().add<player_controller2>("MOVE_LEFT", this, &player_controller2::move_left);
		input_manager::instance().add<player_controller2>("MOVE_RIGHT", this, &player_controller2::move_right);
		input_manager::instance().add<player_controller2>("MOVE_UP", this, &player_controller2::move_up);
		input_manager::instance().add<player_controller2>("MOVE_DOWN", this, &player_controller2::move_down);
	}
	void move_right()
	{
		set_pos(15, 0);
	}
	void move_left()
	{
		set_pos(-15, 0);
	}
	void move_up()
	{
		set_pos(0, -15);
	}
	void move_down()
	{
		set_pos(0, 15);
	}
};

class trigger : public entity
{
private:
	player_controller2 * player_controller_;
public:
	trigger(player_controller2 * pl) : entity("trigger.png", true), player_controller_(pl)
	{
		set_pos(25, 25);
		input_manager::instance().add<trigger>("ACTION", this, &trigger::action);
	}
	void action()
	{
		if (get_sprite().check_collison(player_controller_->get_sprite().spritee.getGlobalBounds())) {
			std::cout << "action" << std::endl;
		}
	}
};


int main(int, char**)
{
	srand(time(nullptr));


	std::vector<entity*> entities;
	entities.push_back(new player_controller2());
	entities.push_back(new trigger(dynamic_cast<player_controller2*>(entities.front())));

	sf::RenderWindow window(sf::VideoMode(800, 600), "Solar Engine");

	while (window.isOpen())
	{
		input_manager::instance().handle_input(window);
		window.clear();
		for(auto & ent : entities)
			ent->render(window);
		window.display();
	}

}
