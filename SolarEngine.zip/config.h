#pragma once
#include <SFML/Graphics.hpp>

namespace config {
	enum input
	{
		move_right = sf::Keyboard::Key::Right,
		move_left = sf::Keyboard::Key::Left,
		move_up = sf::Keyboard::Key::Up,
		move_down = sf::Keyboard::Key::Down,
		action = sf::Keyboard::Key::E
	};
}