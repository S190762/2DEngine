#pragma once
#include "singleton.h"
#include <map>
#include "event_callback.h"
#include "event.h"
#include <SFML/Graphics.hpp>
#include "config.h"

class input_manager : public singleton<input_manager>
{
private:
	std::map<std::string, event*> input_events_;
public:
	template<typename T>
	void add(const std::string name, T* instance, void(T::*function)())
	{
		if (input_events_.count(name) < 1)
		{
			input_events_.insert(make_pair(name, new event()));
		}
		input_events_[name]->add_listener(new event_callback<T>(instance, function));
	}
	void add(const std::string name, ievent_callback* action)
	{
		if (input_events_.count(name) < 1)
		{
			input_events_.insert(make_pair(name, new event()));
		}
		input_events_[name]->add_listener(action);
	}
	void handle_input(sf::RenderWindow & window)
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			switch (event.type)
			{
			case sf::Event::Closed:
				window.close();
				break;
			case sf::Event::KeyPressed:
				switch(event.key.code)
				{
					case config::input::move_up:
						input_events_["MOVE_UP"]->fire();
						break;
					case config::input::move_down:
						input_events_["MOVE_DOWN"]->fire();
						break;
					case config::input::move_left:
						input_events_["MOVE_LEFT"]->fire();
						break;
					case config::input::move_right:
						input_events_["MOVE_RIGHT"]->fire();
						break;
					case config::input::action:
						input_events_["ACTION"]->fire();
						break;
					default: break;
				}
				break;
			default:
				break;
			}
		}
	}
};
