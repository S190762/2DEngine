#pragma once
#include "ievent_callback.h"

template<typename T>
class event_callback : public ievent_callback
{
private:
	T* instance_;
	void (T::*function_)();
public:
	event_callback(T* instance, void(T::*function)()) : instance_(instance), function_(function) {}
	void operator() () override { (instance_->*function_)(); }
};

struct int_data
{
	int a;
};

template<typename T>
class data_event_callback : public ievent_callback
{
private:
	T* instance_;
	void * data_;
	void (T::*function_)();
public:
	data_event_callback(T* instance, void * data, void(T::*function)()) : instance_(instance), function_(function), data_(data) {}
	void operator() () override { (instance_->*function_)(); }
};